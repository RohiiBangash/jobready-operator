
export enum Difficulty {
  Easy = 'Easy',
  Medium = 'Medium',
  Hard = 'Hard'
}

export enum QuestionType {
  MCQ = 'MCQ',
  TrueFalse = 'True/False',
  FillBlank = 'Fill in the Blank',
  Scenario = 'Practical Scenario'
}

export enum Subject {
  Word = 'MS Word',
  Excel = 'MS Excel',
  PowerPoint = 'MS PowerPoint',
  Basics = 'Computer Basics',
  Data = 'Data & Data Types',
  DateTime = 'Dates & Time',
  Programming = 'Programming Basics',
  Internet = 'Internet & Email'
}

export interface Question {
  id: string;
  subject: Subject;
  topic: string;
  difficulty: Difficulty;
  type: QuestionType;
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
}

export interface QuizSession {
  questions: Question[];
  userAnswers: Record<string, string>;
  startTime: number;
  endTime?: number;
  score: number;
}

export interface StudyDay {
  day: number;
  focus: string;
  topics: {
    title: string;
    description: string;
    subjects: Subject[];
  }[];
}
