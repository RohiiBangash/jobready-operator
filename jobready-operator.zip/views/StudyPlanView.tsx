
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { STUDY_PLAN } from '../constants';

const StudyPlanView: React.FC = () => {
  const navigate = useNavigate();
  const [completedModules, setCompletedModules] = useState<string[]>([]);

  const toggleModule = (id: string) => {
    setCompletedModules(prev => 
      prev.includes(id) ? prev.filter(mid => mid !== id) : [...prev, id]
    );
  };

  return (
    <div className="space-y-10 animate-fadeIn max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tight mb-2">The 48-Hour Blueprint</h2>
          <p className="text-slate-500 text-lg">Every second counts. Follow this roadmap to mastery.</p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
           <div className="text-right">
             <p className="text-[10px] text-slate-400 uppercase font-black">Overall Progress</p>
             <p className="text-xl font-black text-indigo-600">{Math.round((completedModules.length / (STUDY_PLAN.length * 2)) * 100)}%</p>
           </div>
           <div className="w-16 h-16 rounded-full border-4 border-slate-100 flex items-center justify-center relative">
             <div className="absolute inset-0 rounded-full border-4 border-indigo-600" style={{ clipPath: `inset(0 ${100 - (completedModules.length / 4 * 100)}% 0 0)` }}></div>
             <i className="fas fa-trophy text-slate-300"></i>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-12 relative">
        <div className="absolute left-[23px] top-10 bottom-10 w-1 bg-gradient-to-b from-indigo-600 via-indigo-200 to-transparent hidden md:block"></div>

        {STUDY_PLAN.map((day) => (
          <div key={day.day} className="relative group">
            <div className="flex gap-8">
              <div className="relative z-10 shrink-0 hidden md:block">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-xl shadow-xl transition-all duration-300 ${
                  day.day === 1 ? 'bg-indigo-600 text-white scale-110' : 'bg-white text-indigo-600 border-4 border-indigo-600'
                }`}>
                  {day.day}
                </div>
              </div>
              
              <div className="flex-1">
                <div className="mb-6">
                  <span className="text-indigo-600 font-black text-xs uppercase tracking-[0.2em] mb-1 block">Phase {day.day}</span>
                  <h3 className="text-3xl font-black text-slate-900 leading-none">{day.focus}</h3>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {day.topics.map((topic, idx) => {
                    const moduleId = `${day.day}-${idx}`;
                    const isDone = completedModules.includes(moduleId);
                    return (
                      <div 
                        key={idx} 
                        className={`bg-white p-8 rounded-[2rem] border-2 transition-all duration-300 relative group cursor-pointer ${
                          isDone ? 'border-green-200 bg-green-50/20' : 'border-slate-100 hover:border-indigo-200 hover:shadow-2xl'
                        }`}
                        onClick={() => toggleModule(moduleId)}
                      >
                        <div className="flex items-center justify-between mb-6">
                          <h4 className={`font-black text-xl tracking-tight transition-colors ${isDone ? 'text-green-800' : 'text-slate-800'}`}>
                            {topic.title}
                          </h4>
                          <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all ${
                            isDone ? 'bg-green-500 border-green-500 text-white' : 'border-slate-200 text-transparent group-hover:border-indigo-300'
                          }`}>
                            <i className="fas fa-check text-xs"></i>
                          </div>
                        </div>
                        <p className="text-slate-500 text-sm leading-relaxed mb-8">
                          {topic.description}
                        </p>
                        
                        <div className="flex flex-wrap gap-2 mb-8">
                          {topic.subjects.map(s => (
                            <span key={s} className="bg-slate-100 text-slate-600 text-[10px] px-3 py-1 rounded-lg font-bold uppercase tracking-widest border border-slate-200">
                              {s}
                            </span>
                          ))}
                        </div>

                        <div className="flex gap-3">
                          <button 
                            onClick={(e) => { e.stopPropagation(); navigate(`/practice?subject=${topic.subjects[0]}`); }}
                            className="flex-1 bg-slate-900 text-white text-xs font-bold py-3 rounded-xl hover:bg-indigo-600 transition-colors uppercase tracking-widest shadow-lg"
                          >
                            Practice Quiz
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-gradient-to-br from-indigo-900 to-slate-900 rounded-[3rem] p-12 text-white mt-12 flex flex-col md:flex-row items-center justify-between gap-10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full -mr-32 -mt-32 blur-3xl"></div>
        <div className="relative z-10">
          <h3 className="text-4xl font-black mb-4 tracking-tighter">Ready for the Real Thing?</h3>
          <p className="text-indigo-200 text-lg max-w-xl">
            Our Final Revision Mock Test simulates a real Computer Operator examination. 
            Timed, scored, and comprehensive.
          </p>
        </div>
        <button 
          onClick={() => navigate('/mock-test')}
          className="bg-green-500 hover:bg-green-400 text-slate-900 px-12 py-5 rounded-2xl font-black transition-all shadow-[0_0_20px_rgba(34,197,94,0.4)] whitespace-nowrap text-lg uppercase tracking-widest hover:scale-105 active:scale-95"
        >
          Launch Final Exam
        </button>
      </div>
    </div>
  );
};

export default StudyPlanView;
