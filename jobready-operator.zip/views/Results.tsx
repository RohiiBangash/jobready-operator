
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Subject, Question } from '../types';

const Results: React.FC = () => {
  const navigate = useNavigate();
  const resultsStr = localStorage.getItem('last_test_results');
  
  if (!resultsStr) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold mb-4">No results found</h2>
        <Link to="/" className="text-indigo-600 underline">Back to Dashboard</Link>
      </div>
    );
  }

  const results = JSON.parse(resultsStr);
  const { score, total, questions, answers } = results;
  const percentage = Math.round((score / total) * 100);

  // Group by subject to find weak areas
  const subjectStats: Record<string, { correct: number, total: number }> = {};
  questions.forEach((q: Question) => {
    if (!subjectStats[q.subject]) subjectStats[q.subject] = { correct: 0, total: 0 };
    subjectStats[q.subject].total++;
    if (answers[q.id]?.toLowerCase() === q.correctAnswer.toLowerCase()) {
      subjectStats[q.subject].correct++;
    }
  });

  const weakAreas = Object.entries(subjectStats)
    .filter(([_, stats]) => (stats.correct / stats.total) < 0.7)
    .map(([subj]) => subj);

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
        <div className="bg-indigo-900 p-12 text-center text-white relative">
          <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
            <i className="fas fa-trophy absolute top-10 right-10 text-9xl"></i>
            <i className="fas fa-star absolute bottom-10 left-10 text-8xl"></i>
          </div>

          <p className="text-indigo-300 font-bold uppercase tracking-widest mb-4">Test Complete</p>
          <h2 className="text-5xl font-black mb-6">Your Score: {percentage}%</h2>
          
          <div className="flex justify-center items-center gap-8 mb-8">
            <div className="text-center">
              <p className="text-3xl font-bold">{score}</p>
              <p className="text-indigo-300 text-sm">Correct</p>
            </div>
            <div className="h-10 w-px bg-indigo-700"></div>
            <div className="text-center">
              <p className="text-3xl font-bold">{total - score}</p>
              <p className="text-indigo-300 text-sm">Incorrect</p>
            </div>
            <div className="h-10 w-px bg-indigo-700"></div>
            <div className="text-center">
              <p className="text-3xl font-bold">{total}</p>
              <p className="text-indigo-300 text-sm">Total Questions</p>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-4">
            <Link 
              to="/mock-test"
              className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 rounded-xl font-bold transition-all shadow-lg"
            >
              Try Again
            </Link>
            <Link 
              to="/"
              className="bg-indigo-800 text-white border border-indigo-700 px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all"
            >
              Go to Dashboard
            </Link>
          </div>
        </div>

        <div className="p-8">
          <h3 className="text-xl font-bold text-slate-800 mb-6">Performance by Subject</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-10">
            {Object.entries(subjectStats).map(([subj, stats]) => {
              const perc = Math.round((stats.correct / stats.total) * 100);
              return (
                <div key={subj} className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-slate-700">{subj}</span>
                    <span className={`text-sm font-bold ${perc >= 80 ? 'text-green-600' : perc >= 50 ? 'text-amber-600' : 'text-red-600'}`}>
                      {perc}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div 
                      className={`h-2 rounded-full transition-all duration-1000 ${perc >= 80 ? 'bg-green-500' : perc >= 50 ? 'bg-amber-500' : 'bg-red-500'}`}
                      style={{ width: `${perc}%` }}
                    ></div>
                  </div>
                  <p className="text-xs text-slate-400 mt-2">{stats.correct} correct out of {stats.total}</p>
                </div>
              );
            })}
          </div>

          {weakAreas.length > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-6 mb-8">
              <h4 className="text-amber-800 font-bold flex items-center gap-2 mb-2">
                <i className="fas fa-exclamation-triangle"></i>
                Weak Area Analysis
              </h4>
              <p className="text-amber-700 text-sm mb-4">
                You scored below 70% in the following subjects. We recommend reviewing these modules in Day 1 and Day 2 study plans:
              </p>
              <div className="flex flex-wrap gap-2">
                {weakAreas.map(wa => (
                  <span key={wa} className="bg-white border border-amber-300 text-amber-800 text-xs px-3 py-1 rounded-full font-bold">
                    {wa}
                  </span>
                ))}
              </div>
            </div>
          )}

          <h3 className="text-xl font-bold text-slate-800 mb-6">Detailed Review</h3>
          <div className="space-y-4">
            {questions.map((q: Question, idx: number) => {
              const isCorrect = answers[q.id]?.toLowerCase() === q.correctAnswer.toLowerCase();
              return (
                <div key={q.id} className={`p-6 rounded-2xl border-2 ${isCorrect ? 'border-green-100 bg-green-50/30' : 'border-red-100 bg-red-50/30'}`}>
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-3">
                      <span className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${isCorrect ? 'bg-green-500' : 'bg-red-500'}`}>
                        {idx + 1}
                      </span>
                      <h4 className="font-bold text-slate-800">{q.question}</h4>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div className="text-sm">
                      <p className="text-slate-400 uppercase font-bold text-[10px] tracking-widest mb-1">Your Answer</p>
                      <p className={`font-bold ${isCorrect ? 'text-green-700' : 'text-red-700'}`}>
                        {answers[q.id] || "No answer provided"}
                      </p>
                    </div>
                    {!isCorrect && (
                      <div className="text-sm">
                        <p className="text-slate-400 uppercase font-bold text-[10px] tracking-widest mb-1">Correct Answer</p>
                        <p className="font-bold text-green-700">{q.correctAnswer}</p>
                      </div>
                    )}
                  </div>

                  <div className="bg-white p-4 rounded-xl border border-slate-100">
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mb-1">Explanation</p>
                    <p className="text-sm text-slate-600 leading-relaxed">{q.explanation}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Results;
