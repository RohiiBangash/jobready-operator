
import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { GoogleGenAI, Type } from "@google/genai";
import { QUESTION_BANK } from '../constants';
import { Subject, Question, QuestionType, Difficulty } from '../types';

const Practice: React.FC = () => {
  const [searchParams] = useSearchParams();
  const initialSubject = (searchParams.get('subject') as Subject) || Subject.Word;
  
  const [activeSubject, setActiveSubject] = useState<Subject>(initialSubject);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showExplanation, setShowExplanation] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [isAIActive, setIsAIActive] = useState(false);
  const [aiQuestion, setAiQuestion] = useState<Question | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const staticQuestions = QUESTION_BANK.filter(q => q.subject === activeSubject);
  const currentQuestion = isAIActive ? aiQuestion : staticQuestions[currentIndex];

  useEffect(() => {
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setShowExplanation(false);
    setIsCorrect(null);
    setAiQuestion(null);
    setIsAIActive(false);
  }, [activeSubject]);

  const generateAIQuestion = async () => {
    setIsLoading(true);
    setIsAIActive(true);
    setShowExplanation(false);
    setSelectedAnswer(null);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Generate a high-quality interview question for the role of Computer Operator. 
        Topic: ${activeSubject}. Difficulty: Medium or Hard.
        The output must be JSON format.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              options: { type: Type.ARRAY, items: { type: Type.STRING } },
              correctAnswer: { type: Type.STRING },
              explanation: { type: Type.STRING },
              topic: { type: Type.STRING },
              difficulty: { type: Type.STRING }
            },
            required: ["question", "options", "correctAnswer", "explanation", "topic", "difficulty"]
          }
        }
      });

      const data = JSON.parse(response.text);
      setAiQuestion({
        id: `ai-${Date.now()}`,
        subject: activeSubject,
        topic: data.topic,
        difficulty: data.difficulty as Difficulty,
        type: QuestionType.MCQ,
        question: data.question,
        options: data.options,
        correctAnswer: data.correctAnswer,
        explanation: data.explanation
      });
    } catch (error) {
      console.error("AI Generation failed", error);
      setIsAIActive(false);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAnswer = (answer: string) => {
    if (showExplanation || !currentQuestion) return;
    setSelectedAnswer(answer);
    const correct = answer.toLowerCase().trim() === currentQuestion.correctAnswer.toLowerCase().trim();
    setIsCorrect(correct);
    setShowExplanation(true);
  };

  const nextQuestion = () => {
    if (isAIActive) {
      generateAIQuestion();
    } else if (currentIndex < staticQuestions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
      setIsCorrect(null);
    } else {
      setIsAIActive(true);
      generateAIQuestion();
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn max-w-4xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
        <div className="flex flex-wrap gap-2">
          {Object.values(Subject).map((s) => (
            <button
              key={s}
              onClick={() => setActiveSubject(s)}
              className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-tight transition-all duration-200 ${
                activeSubject === s 
                  ? 'bg-indigo-600 text-white shadow-lg' 
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
        <button 
          onClick={generateAIQuestion}
          disabled={isLoading}
          className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-2 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 hover:scale-105 transition-all shadow-lg"
        >
          {isLoading ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-magic"></i>}
          Smart AI Practice
        </button>
      </div>

      <div className="bg-white rounded-[2rem] border border-slate-200 shadow-2xl overflow-hidden min-h-[500px] flex flex-col">
        {isLoading ? (
          <div className="flex-1 flex flex-col items-center justify-center p-20 text-center">
            <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-6"></div>
            <h3 className="text-xl font-bold text-slate-800">Generating Expert Question...</h3>
            <p className="text-slate-500 mt-2">Gemini is analyzing interview patterns for {activeSubject}.</p>
          </div>
        ) : currentQuestion ? (
          <>
            <div className="bg-slate-50 px-10 py-6 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <span className="bg-indigo-600 text-white text-[10px] font-black px-3 py-1 rounded-lg uppercase tracking-widest">
                  {currentQuestion.difficulty}
                </span>
                <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest">
                  {currentQuestion.topic} {isAIActive && <span className="text-purple-500 ml-2">(AI GENERATED)</span>}
                </span>
              </div>
              <span className="text-slate-400 font-bold text-sm">
                {isAIActive ? 'Infinite Practice' : `Question ${currentIndex + 1} of ${staticQuestions.length}`}
              </span>
            </div>

            <div className="p-10 flex-1">
              <h2 className="text-2xl font-bold text-slate-800 mb-10 leading-tight">
                {currentQuestion.question}
              </h2>

              <div className="grid grid-cols-1 gap-4">
                {currentQuestion.options ? (
                  currentQuestion.options.map((opt, i) => (
                    <button
                      key={i}
                      onClick={() => handleAnswer(opt)}
                      disabled={showExplanation}
                      className={`w-full text-left p-5 rounded-2xl border-2 transition-all flex items-center justify-between group ${
                        selectedAnswer === opt
                          ? isCorrect 
                            ? 'border-green-500 bg-green-50 text-green-800'
                            : 'border-red-500 bg-red-50 text-red-800'
                          : showExplanation && opt === currentQuestion.correctAnswer
                            ? 'border-green-500 bg-green-50 text-green-800'
                            : 'border-slate-100 bg-slate-50/50 hover:border-indigo-300 hover:bg-white hover:shadow-md'
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                           selectedAnswer === opt ? (isCorrect ? 'bg-green-500 text-white' : 'bg-red-500 text-white') : 'bg-white border border-slate-200 text-slate-400'
                        }`}>
                          {String.fromCharCode(65 + i)}
                        </div>
                        <span className="font-semibold text-lg">{opt}</span>
                      </div>
                      {selectedAnswer === opt && (
                        <i className={`fas ${isCorrect ? 'fa-check-circle text-green-500' : 'fa-times-circle text-red-500'} text-xl`}></i>
                      )}
                    </button>
                  ))
                ) : (
                  <div className="space-y-4">
                    <input 
                      type="text"
                      placeholder="Type your answer and press Enter..."
                      className="w-full p-5 border-2 border-slate-200 rounded-2xl focus:border-indigo-500 outline-none text-xl bg-slate-50"
                      onKeyPress={(e) => {
                        if (e.key === 'Enter') handleAnswer((e.target as HTMLInputElement).value);
                      }}
                      disabled={showExplanation}
                    />
                    {!showExplanation && (
                      <button 
                        onClick={() => {
                          const input = document.querySelector('input') as HTMLInputElement;
                          handleAnswer(input.value);
                        }}
                        className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg"
                      >
                        Check Answer
                      </button>
                    )}
                  </div>
                )}
              </div>

              {showExplanation && (
                <div className={`mt-10 p-8 rounded-[2rem] animate-slideUp border-l-8 ${isCorrect ? 'bg-green-50 border-green-500' : 'bg-red-50 border-red-500'}`}>
                  <h4 className={`text-xl font-black mb-3 flex items-center gap-3 ${isCorrect ? 'text-green-800' : 'text-red-800'}`}>
                    <i className={`fas ${isCorrect ? 'fa-check-circle' : 'fa-lightbulb'}`}></i>
                    {isCorrect ? 'PERFECT!' : 'LEARNING MOMENT'}
                  </h4>
                  <div className="space-y-3">
                     <p className={`text-lg leading-relaxed font-medium ${isCorrect ? 'text-green-700' : 'text-red-700'}`}>
                       {currentQuestion.explanation}
                     </p>
                     {!isCorrect && (
                       <div className="bg-white/50 p-4 rounded-xl inline-block border border-red-100">
                         <span className="text-red-400 text-xs font-bold uppercase tracking-widest mr-2">The Correct Answer Is:</span>
                         <span className="font-bold text-red-700 text-lg">{currentQuestion.correctAnswer}</span>
                       </div>
                     )}
                  </div>
                  
                  <div className="mt-8 flex justify-end">
                    <button 
                      onClick={nextQuestion}
                      className="bg-indigo-900 text-white px-10 py-4 rounded-2xl font-black shadow-2xl hover:bg-black transition-all flex items-center gap-3 uppercase tracking-tighter"
                    >
                      {currentIndex === staticQuestions.length - 1 && !isAIActive ? 'Enter AI Mode' : 'Next Question'}
                      <i className="fas fa-chevron-right"></i>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center p-20 text-center">
            <h3 className="text-xl font-bold">No questions found for this subject.</h3>
          </div>
        )}
      </div>
    </div>
  );
};

export default Practice;
