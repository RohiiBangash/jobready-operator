
import React from 'react';
import { Link } from 'react-router-dom';
import { Subject } from '../types';

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-8 animate-fadeIn">
      <section className="bg-gradient-to-r from-indigo-600 to-indigo-800 rounded-3xl p-8 text-white shadow-xl">
        <div className="max-w-2xl">
          <h2 className="text-3xl font-bold mb-2">Ready for the Interview?</h2>
          <p className="text-indigo-100 mb-6">
            You have 2 days to master the Computer Operator fundamentals. Follow our structured path to ensure you cover every topic.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link 
              to="/mock-test"
              className="bg-white text-indigo-600 px-6 py-3 rounded-xl font-bold hover:bg-indigo-50 transition-colors shadow-lg"
            >
              Start Full Mock Test
            </Link>
            <Link 
              to="/study-plan"
              className="bg-indigo-500 text-white border border-indigo-400 px-6 py-3 rounded-xl font-bold hover:bg-indigo-400 transition-colors"
            >
              View Study Plan
            </Link>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="bg-blue-100 w-12 h-12 rounded-xl flex items-center justify-center text-blue-600 mb-4 text-xl">
            <i className="fas fa-clock"></i>
          </div>
          <h3 className="font-bold text-slate-800">Day 1 Focus</h3>
          <p className="text-sm text-slate-500 mb-4">Office Tools & Basics</p>
          <div className="flex items-center justify-between text-sm">
            <span className="text-blue-600 font-medium">85% Complete</span>
            <span className="text-slate-400">Next: Excel Formulas</span>
          </div>
          <div className="mt-3 w-full bg-slate-100 rounded-full h-1.5">
            <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: '85%' }}></div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="bg-purple-100 w-12 h-12 rounded-xl flex items-center justify-center text-purple-600 mb-4 text-xl">
            <i className="fas fa-database"></i>
          </div>
          <h3 className="font-bold text-slate-800">Day 2 Focus</h3>
          <p className="text-sm text-slate-500 mb-4">Internet, Data & Logic</p>
          <div className="flex items-center justify-between text-sm">
            <span className="text-purple-600 font-medium">10% Complete</span>
            <span className="text-slate-400">Locked</span>
          </div>
          <div className="mt-3 w-full bg-slate-100 rounded-full h-1.5">
            <div className="bg-purple-500 h-1.5 rounded-full" style={{ width: '10%' }}></div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="bg-green-100 w-12 h-12 rounded-xl flex items-center justify-center text-green-600 mb-4 text-xl">
            <i className="fas fa-trophy"></i>
          </div>
          <h3 className="font-bold text-slate-800">Best Performance</h3>
          <p className="text-sm text-slate-500 mb-4">MS Word Section</p>
          <div className="flex items-center justify-between text-sm">
            <span className="text-green-600 font-medium">92% Score</span>
            <span className="text-slate-400">High Score</span>
          </div>
          <div className="mt-3 w-full bg-slate-100 rounded-full h-1.5">
            <div className="bg-green-500 h-1.5 rounded-full" style={{ width: '92%' }}></div>
          </div>
        </div>
      </div>

      <section>
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-slate-800">Practice by Subject</h3>
          <Link to="/practice" className="text-indigo-600 hover:underline text-sm font-medium">View all</Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { name: Subject.Word, icon: 'fa-file-word', color: 'text-blue-600', bg: 'bg-blue-50' },
            { name: Subject.Excel, icon: 'fa-file-excel', color: 'text-emerald-600', bg: 'bg-emerald-50' },
            { name: Subject.PowerPoint, icon: 'fa-file-powerpoint', color: 'text-orange-600', bg: 'bg-orange-50' },
            { name: Subject.Basics, icon: 'fa-microchip', color: 'text-slate-600', bg: 'bg-slate-100' },
          ].map((subj) => (
            <Link 
              key={subj.name}
              to={`/practice?subject=${subj.name}`}
              className="bg-white p-4 rounded-2xl border border-slate-200 hover:border-indigo-300 hover:shadow-md transition-all text-center"
            >
              <div className={`${subj.bg} ${subj.color} w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-3`}>
                <i className={`fas ${subj.icon}`}></i>
              </div>
              <p className="text-sm font-bold text-slate-700">{subj.name}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="bg-amber-50 border border-amber-200 p-6 rounded-2xl">
        <h3 className="font-bold text-amber-800 mb-2 flex items-center gap-2">
          <i className="fas fa-lightbulb"></i>
          Weak Area Alert
        </h3>
        <p className="text-sm text-amber-700">
          Based on your last mock test, you're struggling with <strong>Excel Absolute Cell References</strong> and <strong>Internet Protocols</strong>. 
          We recommend spending 15 minutes reviewing these topics in the Study Plan.
        </p>
      </section>
    </div>
  );
};

export default Dashboard;
