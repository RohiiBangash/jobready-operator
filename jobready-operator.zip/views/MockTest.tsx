
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { QUESTION_BANK } from '../constants';
import { Question } from '../types';

const MockTest: React.FC = () => {
  const navigate = useNavigate();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<string, string>>({});
  const [timeLeft, setTimeLeft] = useState(1500); // 25 minutes
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    // Generate a fresh set of 25 questions
    const shuffled = [...QUESTION_BANK].sort(() => 0.5 - Math.random());
    setQuestions(shuffled.slice(0, 25));
  }, []);

  const finishTest = useCallback(() => {
    if (isSubmitting) return;
    setIsSubmitting(true);
    
    let score = 0;
    questions.forEach(q => {
      const userAnswer = (userAnswers[q.id] || "").trim().toLowerCase();
      const correctAnswer = q.correctAnswer.trim().toLowerCase();
      if (userAnswer === correctAnswer) {
        score++;
      }
    });

    const results = {
      score,
      total: questions.length,
      answers: userAnswers,
      questions: questions,
      timestamp: Date.now()
    };

    localStorage.setItem('last_test_results', JSON.stringify(results));
    navigate('/results');
  }, [isSubmitting, questions, userAnswers, navigate]);

  useEffect(() => {
    if (timeLeft <= 0) {
      finishTest();
      return;
    }
    const timer = setInterval(() => {
      setTimeLeft(prev => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [timeLeft, finishTest]);

  const handleAnswer = (answer: string) => {
    setUserAnswers(prev => ({
      ...prev,
      [questions[currentIndex].id]: answer
    }));
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  if (questions.length === 0) return (
    <div className="flex flex-col items-center justify-center py-20 animate-pulse">
      <div className="w-12 h-12 bg-indigo-600 rounded-xl animate-spin mb-4"></div>
      <p className="font-bold text-slate-500">PREPARING EXAM PAPER...</p>
    </div>
  );

  const currentQuestion = questions[currentIndex];

  return (
    <div className="max-w-5xl mx-auto animate-fadeIn pb-20">
      <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-xl flex flex-col md:flex-row items-center justify-between sticky top-24 z-10 mb-8 gap-6">
        <div className="flex items-center gap-6 w-full md:w-auto">
          <div className="h-16 w-16 bg-slate-900 text-white rounded-2xl flex flex-col items-center justify-center shadow-lg">
            <span className="text-[10px] font-black uppercase tracking-tighter leading-none mb-1">Ques</span>
            <span className="text-xl font-black leading-none">{currentIndex + 1}</span>
          </div>
          <div>
            <p className="text-xs text-slate-400 font-black uppercase tracking-widest mb-1">Total Progress</p>
            <div className="flex items-center gap-3">
               <div className="w-32 h-3 bg-slate-100 rounded-full overflow-hidden">
                 <div className="h-full bg-indigo-600 transition-all duration-300" style={{ width: `${(currentIndex / questions.length) * 100}%` }}></div>
               </div>
               <span className="font-black text-slate-800">{currentIndex + 1}/{questions.length}</span>
            </div>
          </div>
        </div>

        <div className={`flex items-center gap-4 px-8 py-4 rounded-2xl border-4 transition-colors ${timeLeft < 300 ? 'border-red-500 bg-red-50 text-red-600 animate-pulse' : 'border-slate-900 bg-slate-900 text-white'}`}>
          <i className="fas fa-clock text-xl"></i>
          <span className="text-3xl font-black font-mono tracking-tighter">{formatTime(timeLeft)}</span>
        </div>

        <button 
          onClick={() => { if (window.confirm("Final check: Ready to submit?")) finishTest(); }}
          className="bg-green-600 text-white px-10 py-4 rounded-2xl font-black hover:bg-green-700 transition-all shadow-xl text-lg uppercase tracking-widest hover:scale-105"
        >
          Submit Exam
        </button>
      </div>

      <div className="bg-white rounded-[3rem] border border-slate-200 shadow-2xl p-10 md:p-16 mb-10 transition-all">
        <div className="flex items-center gap-3 mb-10">
          <span className="bg-indigo-100 text-indigo-700 font-black text-xs px-4 py-1.5 rounded-full uppercase tracking-[0.2em]">{currentQuestion.subject}</span>
          <div className="h-1 w-1 bg-slate-300 rounded-full"></div>
          <span className="text-slate-400 text-xs font-bold uppercase tracking-widest">{currentQuestion.topic}</span>
        </div>

        <h2 className="text-3xl font-black text-slate-900 mb-12 leading-tight">
          {currentQuestion.question}
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {currentQuestion.options ? (
            currentQuestion.options.map((opt, i) => (
              <button
                key={i}
                onClick={() => handleAnswer(opt)}
                className={`w-full text-left p-6 rounded-3xl border-4 transition-all flex items-center gap-5 group relative overflow-hidden ${
                  userAnswers[currentQuestion.id] === opt
                    ? 'border-indigo-600 bg-indigo-50 text-indigo-900 shadow-2xl scale-[1.02]'
                    : 'border-slate-50 bg-slate-50/50 hover:border-slate-200 hover:bg-white hover:shadow-lg'
                }`}
              >
                <div className={`w-10 h-10 rounded-xl border-2 flex items-center justify-center flex-shrink-0 font-black text-lg transition-all ${
                  userAnswers[currentQuestion.id] === opt ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' : 'bg-white border-slate-200 text-slate-300 group-hover:border-indigo-200'
                }`}>
                  {String.fromCharCode(65 + i)}
                </div>
                <span className="text-xl font-bold tracking-tight">{opt}</span>
              </button>
            ))
          ) : (
            <input 
              type="text"
              value={userAnswers[currentQuestion.id] || ''}
              onChange={(e) => handleAnswer(e.target.value)}
              placeholder="Type your official answer..."
              className="w-full col-span-2 p-8 border-4 border-slate-100 rounded-[2rem] focus:border-indigo-600 outline-none text-2xl font-bold bg-slate-50"
            />
          )}
        </div>
      </div>

      <div className="flex justify-between items-center gap-6 px-4">
        <button
          onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
          disabled={currentIndex === 0}
          className={`px-10 py-5 rounded-2xl font-black text-lg transition-all uppercase tracking-widest ${
            currentIndex === 0 ? 'text-slate-300 cursor-not-allowed opacity-50' : 'bg-white text-slate-700 shadow-lg hover:bg-slate-50'
          }`}
        >
          <i className="fas fa-arrow-left mr-3"></i> Back
        </button>

        <div className="hidden lg:flex gap-2 p-4 bg-white rounded-2xl border border-slate-100 shadow-inner">
          {questions.map((_, i) => (
            <div 
              key={i} 
              className={`h-3 w-3 rounded-full transition-all duration-300 ${
                i === currentIndex ? 'bg-indigo-600 scale-150 shadow-[0_0_8px_indigo]' :
                userAnswers[questions[i].id] ? 'bg-green-400' : 'bg-slate-200'
              }`}
            ></div>
          ))}
        </div>

        <button
          onClick={() => {
            if (currentIndex < questions.length - 1) {
              setCurrentIndex(prev => prev + 1);
            } else {
              finishTest();
            }
          }}
          className="bg-indigo-900 text-white px-12 py-5 rounded-2xl font-black text-lg shadow-2xl hover:bg-black transition-all flex items-center gap-4 uppercase tracking-widest hover:scale-105"
        >
          {currentIndex === questions.length - 1 ? 'Finish Exam' : 'Next Question'}
          <i className="fas fa-chevron-right"></i>
        </button>
      </div>
    </div>
  );
};

export default MockTest;
