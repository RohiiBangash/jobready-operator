
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import { Subject, Question, Difficulty, QuizSession } from './types';
import { QUESTION_BANK, STUDY_PLAN } from './constants';
import Dashboard from './views/Dashboard';
import Practice from './views/Practice';
import MockTest from './views/MockTest';
import Results from './views/Results';
import StudyPlanView from './views/StudyPlanView';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-50">
      {/* Sidebar - Desktop */}
      <aside className="w-full md:w-64 bg-slate-900 text-white flex-shrink-0 md:sticky md:top-0 md:h-screen shadow-2xl z-20">
        <div className="p-8">
          <h1 className="text-2xl font-black tracking-tighter flex items-center gap-2">
            <span className="bg-indigo-600 px-2 py-1 rounded-lg">JR</span>
            JobReady
          </h1>
          <p className="text-slate-400 text-[10px] uppercase font-bold tracking-widest mt-2 ml-1">Operator Pro</p>
        </div>
        <nav className="mt-4 px-4 space-y-2">
          <Link
            to="/"
            className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
              isActive('/') ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <i className="fas fa-th-large w-5"></i> Dashboard
          </Link>
          <Link
            to="/study-plan"
            className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
              isActive('/study-plan') ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <i className="fas fa-calendar-check w-5"></i> 2-Day Study Plan
          </Link>
          <Link
            to="/practice"
            className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
              isActive('/practice') ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <i className="fas fa-graduation-cap w-5"></i> AI Practice
          </Link>
          <Link
            to="/mock-test"
            className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
              isActive('/mock-test') ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <i className="fas fa-bolt w-5"></i> Mock Exam
          </Link>
        </nav>
        <div className="absolute bottom-8 left-6 right-6">
          <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700">
            <div className="flex justify-between items-center mb-2">
              <p className="text-[10px] text-slate-400 uppercase font-bold">Preparation Level</p>
              <p className="text-xs text-indigo-400 font-bold">72%</p>
            </div>
            <div className="w-full bg-slate-900 rounded-full h-2">
              <div className="bg-indigo-500 h-2 rounded-full shadow-[0_0_8px_rgba(99,102,241,0.6)]" style={{ width: '72%' }}></div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 h-screen overflow-y-auto">
        <header className="h-20 bg-white/80 backdrop-blur-md border-b border-slate-200 flex items-center justify-between px-8 sticky top-0 z-10">
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-3">
             <span className="md:hidden bg-indigo-600 text-white px-2 py-0.5 rounded">JR</span>
             {isActive('/') ? 'Welcome Back' : isActive('/study-plan') ? 'Your Roadmap' : isActive('/practice') ? 'Smart Practice' : 'Final Exam'}
          </h2>
          <div className="flex items-center gap-4">
            <div className="hidden lg:flex flex-col items-end mr-4">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-tighter">Current Goal</span>
              <span className="text-sm font-bold text-indigo-600">Computer Operator Role</span>
            </div>
            <div className="h-10 w-10 bg-indigo-100 rounded-xl flex items-center justify-center text-indigo-700 font-black border border-indigo-200 shadow-sm">
              JO
            </div>
          </div>
        </header>

        <div className="p-6 md:p-10 max-w-7xl mx-auto w-full">
          {children}
        </div>
      </main>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/study-plan" element={<StudyPlanView />} />
          <Route path="/practice" element={<Practice />} />
          <Route path="/mock-test" element={<MockTest />} />
          <Route path="/results" element={<Results />} />
        </Routes>
      </Layout>
    </HashRouter>
  );
};

export default App;
