
import { Question, Subject, Difficulty, QuestionType, StudyDay } from './types';

export const STUDY_PLAN: StudyDay[] = [
  {
    day: 1,
    focus: "Office Tools & Fundamentals",
    topics: [
      {
        title: "Productivity Suite",
        description: "Master MS Word formatting, Excel formulas, and PowerPoint transitions.",
        subjects: [Subject.Word, Subject.Excel, Subject.PowerPoint]
      },
      {
        title: "Hardware & OS",
        description: "Understanding RAM vs ROM, I/O devices, and basic troubleshooting.",
        subjects: [Subject.Basics]
      }
    ]
  },
  {
    day: 2,
    focus: "Logic, Internet & Data",
    topics: [
      {
        title: "Data Management",
        description: "Focus on data types, date functions, and file extensions.",
        subjects: [Subject.Data, Subject.DateTime]
      },
      {
        title: "Web & Logic",
        description: "Email etiquette, browser basics, and introductory programming concepts.",
        subjects: [Subject.Internet, Subject.Programming]
      }
    ]
  }
];

export const QUESTION_BANK: Question[] = [
  // --- MS WORD ---
  {
    id: "w1",
    subject: Subject.Word,
    topic: "Formatting",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "What is the shortcut key for centering text in MS Word?",
    options: ["Ctrl + L", "Ctrl + E", "Ctrl + R", "Ctrl + J"],
    correctAnswer: "Ctrl + E",
    explanation: "Ctrl + E centers the selected text, while Ctrl + L is for Left, Ctrl + R for Right, and Ctrl + J for Justify."
  },
  {
    id: "w2",
    subject: Subject.Word,
    topic: "Shortcuts",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "Which feature allows you to send the same letter to multiple recipients?",
    options: ["Macro", "Mail Merge", "Template", "Page Setup"],
    correctAnswer: "Mail Merge",
    explanation: "Mail Merge is used to personalize a single document and send it to many people using a data source."
  },
  {
    id: "w3",
    subject: Subject.Word,
    topic: "Headers/Footers",
    difficulty: Difficulty.Easy,
    type: QuestionType.TrueFalse,
    question: "A header appears at the bottom of every page in a document.",
    options: ["True", "False"],
    correctAnswer: "False",
    explanation: "Headers appear at the top, while footers appear at the bottom of the page."
  },
  {
    id: "w4",
    subject: Subject.Word,
    topic: "Find & Replace",
    difficulty: Difficulty.Medium,
    type: QuestionType.FillBlank,
    question: "The shortcut key to open the 'Find and Replace' dialog box is ____.",
    correctAnswer: "Ctrl + H",
    explanation: "Ctrl + H opens the Replace tab directly, while Ctrl + F opens the Navigation/Find pane."
  },
  {
    id: "w5",
    subject: Subject.Word,
    topic: "Tables",
    difficulty: Difficulty.Hard,
    type: QuestionType.Scenario,
    question: "You need to convert a list of names separated by commas into a table. Which option should you use?",
    options: ["Insert -> Table", "Layout -> Table", "Insert -> Table -> Convert Text to Table", "Design -> New Table"],
    correctAnswer: "Insert -> Table -> Convert Text to Table",
    explanation: "This specific tool allows parsing delimited text (commas, tabs) directly into a structured table."
  },
  {
    id: "w6",
    subject: Subject.Word,
    topic: "Styles",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "Applying a 'Style' to text is primarily used for:",
    options: ["Checking spelling", "Ensuring consistent formatting and building TOCs", "Inserting images", "Saving as PDF"],
    correctAnswer: "Ensuring consistent formatting and building TOCs",
    explanation: "Styles provide consistency and are the foundation for generating an automatic Table of Contents."
  },

  // --- MS EXCEL ---
  {
    id: "e1",
    subject: Subject.Excel,
    topic: "Formulas",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "Which symbol must all Excel formulas begin with?",
    options: ["+", "@", "=", "#"],
    correctAnswer: "=",
    explanation: "The equals sign (=) tells Excel that the following characters constitute a formula."
  },
  {
    id: "e2",
    subject: Subject.Excel,
    topic: "Functions",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "Which function is used to look for a value in the leftmost column of a table?",
    options: ["HLOOKUP", "LOOKUP", "VLOOKUP", "MATCH"],
    correctAnswer: "VLOOKUP",
    explanation: "VLOOKUP stands for Vertical Lookup and searches the first column of a range."
  },
  {
    id: "e3",
    subject: Subject.Excel,
    topic: "Cell References",
    difficulty: Difficulty.Hard,
    type: QuestionType.MCQ,
    question: "What does the cell reference $A$1 represent?",
    options: ["Relative reference", "Absolute reference", "Mixed reference", "Invalid reference"],
    correctAnswer: "Absolute reference",
    explanation: "The dollar signs ($) lock both the column and row, so the reference doesn't change when copied."
  },
  {
    id: "e4",
    subject: Subject.Excel,
    topic: "Data Validation",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "Which tool prevents users from entering invalid data into a cell?",
    options: ["Conditional Formatting", "Data Validation", "Goal Seek", "Solver"],
    correctAnswer: "Data Validation",
    explanation: "Data Validation sets rules for what can be entered in a cell, such as a range of numbers or a list."
  },
  {
    id: "e5",
    subject: Subject.Excel,
    topic: "Charts",
    difficulty: Difficulty.Easy,
    type: QuestionType.TrueFalse,
    question: "A Pivot Table is used to summarize and analyze large datasets.",
    options: ["True", "False"],
    correctAnswer: "True",
    explanation: "Pivot Tables are one of Excel's most powerful data summarization tools."
  },
  {
    id: "e6",
    subject: Subject.Excel,
    topic: "Functions",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "Which function adds all the numbers in a range of cells?",
    options: ["COUNT", "SUM", "AVERAGE", "TOTAL"],
    correctAnswer: "SUM",
    explanation: "The SUM function totals all numeric values in the specified range."
  },
  {
    id: "e7",
    subject: Subject.Excel,
    topic: "Sorting",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "To organize names alphabetically from Z to A, you would use:",
    options: ["Ascending Sort", "Descending Sort", "Filter", "Data Validation"],
    correctAnswer: "Descending Sort",
    explanation: "Descending sort orders data from highest to lowest (Z to A or 9 to 0)."
  },

  // --- MS POWERPOINT ---
  {
    id: "p1",
    subject: Subject.PowerPoint,
    topic: "Transitions",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "What is the visual effect that occurs when moving from one slide to another?",
    options: ["Animation", "Transition", "Design", "Layout"],
    correctAnswer: "Transition",
    explanation: "Transitions are the effects applied to the movement between slides."
  },
  {
    id: "p2",
    subject: Subject.PowerPoint,
    topic: "Shortcuts",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "Which key starts a slideshow from the first slide?",
    options: ["F1", "F5", "Ctrl + P", "Spacebar"],
    correctAnswer: "F5",
    explanation: "F5 is the standard shortcut to start a presentation from slide 1."
  },
  {
    id: "p3",
    subject: Subject.PowerPoint,
    topic: "Layouts",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "Which view is used to see all slides as thumbnails on one screen?",
    options: ["Normal View", "Slide Sorter View", "Reading View", "Outline View"],
    correctAnswer: "Slide Sorter View",
    explanation: "Slide Sorter view displays all slides in the presentation in a grid layout."
  },

  // --- COMPUTER BASICS ---
  {
    id: "b1",
    subject: Subject.Basics,
    topic: "Hardware",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "Which of the following is an input device?",
    options: ["Monitor", "Printer", "Keyboard", "Speaker"],
    correctAnswer: "Keyboard",
    explanation: "A keyboard is used to enter data into the computer, making it an input device."
  },
  {
    id: "b2",
    subject: Subject.Basics,
    topic: "Memory",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "Which type of memory is volatile and loses its data when the power is turned off?",
    options: ["ROM", "RAM", "Hard Drive", "Flash Drive"],
    correctAnswer: "RAM",
    explanation: "RAM (Random Access Memory) is temporary storage used while the computer is running."
  },
  {
    id: "b3",
    subject: Subject.Basics,
    topic: "Software",
    difficulty: Difficulty.Easy,
    type: QuestionType.TrueFalse,
    question: "An Operating System is an example of system software.",
    options: ["True", "False"],
    correctAnswer: "True",
    explanation: "OS (like Windows/Linux) manages hardware and other software, thus categorized as System Software."
  },
  {
    id: "b4",
    subject: Subject.Basics,
    topic: "CPU",
    difficulty: Difficulty.Hard,
    type: QuestionType.MCQ,
    question: "What is the small high-speed storage area within the CPU called?",
    options: ["RAM", "Register", "Cache", "Buffer"],
    correctAnswer: "Register",
    explanation: "Registers are the fastest and smallest memory units located inside the CPU."
  },

  // --- DATA & DATA TYPES ---
  {
    id: "d1",
    subject: Subject.Data,
    topic: "Definitions",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "What is 'raw, unorganized facts that need to be processed' called?",
    options: ["Information", "Data", "Knowledge", "Algorithm"],
    correctAnswer: "Data",
    explanation: "Data is the raw material. Once processed and organized, it becomes Information."
  },
  {
    id: "d2",
    subject: Subject.Data,
    topic: "Types",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "Which data type would be best for storing the value '3.14'?",
    options: ["Integer", "String", "Float", "Boolean"],
    correctAnswer: "Float",
    explanation: "Float (or Double) is used for numbers with decimal points."
  },
  {
    id: "d3",
    subject: Subject.Data,
    topic: "Files",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "Which file extension is commonly used for plain text files?",
    options: [".docx", ".pdf", ".txt", ".xlsx"],
    correctAnswer: ".txt",
    explanation: ".txt files contain basic unformatted text."
  },
  {
    id: "d4",
    subject: Subject.Data,
    topic: "Boolean",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "A Boolean data type can only hold which two values?",
    options: ["0 and 1", "Yes and No", "True and False", "High and Low"],
    correctAnswer: "True and False",
    explanation: "Boolean variables represent binary logic states."
  },

  // --- DATES & TIME ---
  {
    id: "dt1",
    subject: Subject.DateTime,
    topic: "Excel Functions",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "Which function in Excel returns the current date and time?",
    options: ["=DATE()", "=TODAY()", "=NOW()", "=TIME()"],
    correctAnswer: "=NOW()",
    explanation: "=NOW() includes both date and time, while =TODAY() only returns the date."
  },
  {
    id: "dt2",
    subject: Subject.DateTime,
    topic: "Time Zones",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "What does UTC stand for in the context of time zones?",
    options: ["United Time Center", "Universal Time Coordinated", "Universal Total Clock", "Union Time Code"],
    correctAnswer: "Universal Time Coordinated",
    explanation: "UTC is the primary time standard by which the world regulates clocks and time."
  },

  // --- PROGRAMMING BASICS ---
  {
    id: "pr1",
    subject: Subject.Programming,
    topic: "Languages",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "Which of these is a high-level programming language?",
    options: ["Python", "Binary", "Assembly", "Machine Code"],
    correctAnswer: "Python",
    explanation: "Python is high-level as it is human-readable, unlike binary or machine code."
  },
  {
    id: "pr2",
    subject: Subject.Programming,
    topic: "Compiler/Interpreter",
    difficulty: Difficulty.Hard,
    type: QuestionType.MCQ,
    question: "A(n) _________ translates program code line-by-line during execution.",
    options: ["Compiler", "Interpreter", "Debugger", "Linker"],
    correctAnswer: "Interpreter",
    explanation: "Interpreters (like Python's) execute code line-by-line, while compilers translate the whole program at once."
  },
  {
    id: "pr3",
    subject: Subject.Programming,
    topic: "Definitions",
    difficulty: Difficulty.Easy,
    type: QuestionType.FillBlank,
    question: "A set of instructions given to a computer to perform a task is called a ____.",
    correctAnswer: "Program",
    explanation: "Software or programs are collections of instructions that computers execute."
  },

  // --- INTERNET & EMAIL ---
  {
    id: "i1",
    subject: Subject.Internet,
    topic: "Email",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "What does 'BCC' stand for in an email context?",
    options: ["Basic Carbon Copy", "Blind Carbon Copy", "Back Carbon Copy", "Business Contact Copy"],
    correctAnswer: "Blind Carbon Copy",
    explanation: "BCC allows you to send an email to someone without other recipients knowing."
  },
  {
    id: "i2",
    subject: Subject.Internet,
    topic: "Browsers",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "Which of the following is a web browser?",
    options: ["Google", "Windows 10", "Google Chrome", "Facebook"],
    correctAnswer: "Google Chrome",
    explanation: "Chrome is the browser; Google is the search engine/company."
  },
  {
    id: "i3",
    subject: Subject.Internet,
    topic: "Etiquette",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "Typing an entire email in ALL CAPS is generally interpreted as:",
    options: ["Urgent", "Professional", "Shouting", "Clear"],
    correctAnswer: "Shouting",
    explanation: "Netiquette dictates that all caps is considered rude or aggressive shouting."
  },
  {
    id: "i4",
    subject: Subject.Internet,
    topic: "Email",
    difficulty: Difficulty.Easy,
    type: QuestionType.TrueFalse,
    question: "You can send a 5GB file directly as a standard email attachment.",
    options: ["True", "False"],
    correctAnswer: "False",
    explanation: "Most email providers limit attachments to 20-25MB. Larger files require cloud links (Drive/Dropbox)."
  },

  // ADDING MORE TO REACH 50+
  {
    id: "e8",
    subject: Subject.Excel,
    topic: "Formatting",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "Which feature combines multiple cells into one large cell?",
    options: ["Split Cells", "Merge & Center", "Format Painter", "Wrap Text"],
    correctAnswer: "Merge & Center",
    explanation: "Merge & Center combines selected cells and centers the content in the new combined cell."
  },
  {
    id: "w7",
    subject: Subject.Word,
    topic: "Shortcuts",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "What is the shortcut key to undo the last action?",
    options: ["Ctrl + Y", "Ctrl + U", "Ctrl + Z", "Ctrl + X"],
    correctAnswer: "Ctrl + Z",
    explanation: "Ctrl + Z undoes, while Ctrl + Y redoes."
  },
  {
    id: "b5",
    subject: Subject.Basics,
    topic: "Storage",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "1 Gigabyte (GB) is equal to how many Megabytes (MB)?",
    options: ["100", "1000", "1024", "2048"],
    correctAnswer: "1024",
    explanation: "In binary-based computing, memory follows powers of 2 (2^10 = 1024)."
  },
  {
    id: "d5",
    subject: Subject.Data,
    topic: "Types",
    difficulty: Difficulty.Medium,
    type: QuestionType.Scenario,
    question: "You are creating a database field to store whether a student has paid their fees or not. Which data type is best?",
    options: ["String", "Integer", "Boolean", "Float"],
    correctAnswer: "Boolean",
    explanation: "Yes/No or Paid/Not Paid is a binary state, best stored as Boolean."
  },
  {
    id: "p4",
    subject: Subject.PowerPoint,
    topic: "Animations",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "What is the difference between transitions and animations?",
    options: [
      "No difference",
      "Transitions apply to slides; Animations apply to objects on slides",
      "Transitions apply to text; Animations apply to images",
      "Animations are for sound only"
    ],
    correctAnswer: "Transitions apply to slides; Animations apply to objects on slides",
    explanation: "Transitions handle moving from slide A to B. Animations handle how text/images appear on a slide."
  },
  {
    id: "i5",
    subject: Subject.Internet,
    topic: "Security",
    difficulty: Difficulty.Hard,
    type: QuestionType.MCQ,
    question: "What does the 's' in HTTPS stand for?",
    options: ["Simple", "Secure", "Socket", "Standard"],
    correctAnswer: "Secure",
    explanation: "HTTPS indicates that the communication is encrypted using SSL/TLS."
  },
  {
    id: "dt3",
    subject: Subject.DateTime,
    topic: "Calculations",
    difficulty: Difficulty.Hard,
    type: QuestionType.FillBlank,
    question: "If cell A1 has '2023-01-01' and B1 has '=A1+7', the result in B1 is ____ (YYYY-MM-DD format).",
    correctAnswer: "2023-01-08",
    explanation: "Excel treats dates as numbers, so adding 7 adds seven days."
  },
  {
    id: "pr4",
    subject: Subject.Programming,
    topic: "Logic",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "A 'Loop' in programming is used to:",
    options: ["Exit the program", "Repeat a block of code", "Define a variable", "Change the font"],
    correctAnswer: "Repeat a block of code",
    explanation: "Loops (for, while) allow code to be executed multiple times based on a condition."
  },
  {
    id: "b6",
    subject: Subject.Basics,
    topic: "OS",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "Which of the following is an open-source operating system?",
    options: ["Windows 11", "macOS", "Linux", "iOS"],
    correctAnswer: "Linux",
    explanation: "Linux is the most famous open-source OS, allowing anyone to modify its source code."
  },
  {
    id: "w8",
    subject: Subject.Word,
    topic: "Page Setup",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "Which page orientation makes the page wider than it is tall?",
    options: ["Portrait", "Landscape", "Vertical", "A4"],
    correctAnswer: "Landscape",
    explanation: "Landscape is horizontal; Portrait is vertical."
  },
  {
    id: "e9",
    subject: Subject.Excel,
    topic: "Sorting",
    difficulty: Difficulty.Medium,
    type: QuestionType.TrueFalse,
    question: "Filtering data in Excel permanently deletes the rows that don't match the criteria.",
    options: ["True", "False"],
    correctAnswer: "False",
    explanation: "Filtering only hides the rows; they can be shown again by clearing the filter."
  },
  {
    id: "i6",
    subject: Subject.Internet,
    topic: "Email",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "A file sent along with an email message is called a(n) ________.",
    options: ["Encapsulation", "Attachment", "Addition", "Module"],
    correctAnswer: "Attachment",
    explanation: "Attachments are files like PDFs, Docs, or Images sent with emails."
  },
  {
    id: "b7",
    subject: Subject.Basics,
    topic: "I/O",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "Which component is often called the 'brain' of the computer?",
    options: ["Motherboard", "CPU", "Hard Disk", "Power Supply"],
    correctAnswer: "CPU",
    explanation: "The Central Processing Unit (CPU) performs all processing and calculations."
  },
  {
    id: "d6",
    subject: Subject.Data,
    topic: "CSV",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "What does CSV stand for?",
    options: ["Central Storage Variable", "Comma Separated Values", "Computer System Visual", "Code Serial Version"],
    correctAnswer: "Comma Separated Values",
    explanation: "CSV files store tabular data as plain text, separated by commas."
  },
  {
    id: "p5",
    subject: Subject.PowerPoint,
    topic: "Best Practices",
    difficulty: Difficulty.Medium,
    type: QuestionType.Scenario,
    question: "What is a recommended 'best practice' for the amount of text on a slide?",
    options: ["Fill every inch with text", "6x6 Rule (max 6 lines, 6 words per line)", "Only use images, no text", "Use comic sans font only"],
    correctAnswer: "6x6 Rule (max 6 lines, 6 words per line)",
    explanation: "The 6x6 rule keeps slides readable and prevents overwhelming the audience."
  },
  {
    id: "dt4",
    subject: Subject.DateTime,
    topic: "Formats",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "In the date format MM/DD/YYYY, what does 'MM' represent?",
    options: ["Minute", "Month", "Moment", "Millisecond"],
    correctAnswer: "Month",
    explanation: "MM stands for Month, DD for Day, and YYYY for Year."
  },
  {
    id: "pr5",
    subject: Subject.Programming,
    topic: "Python",
    difficulty: Difficulty.Hard,
    type: QuestionType.Scenario,
    question: "What is the expected output of the Python code: print(5 + 2 * 3)?",
    options: ["21", "11", "10", "15"],
    correctAnswer: "11",
    explanation: "Order of operations (BODMAS/PEMDAS) dictates multiplication (2*3=6) before addition (5+6=11)."
  },
  {
    id: "w9",
    subject: Subject.Word,
    topic: "Mail Merge",
    difficulty: Difficulty.Hard,
    type: QuestionType.TrueFalse,
    question: "In Mail Merge, the 'Data Source' must be an MS Word document; it cannot be an Excel file.",
    options: ["True", "False"],
    correctAnswer: "False",
    explanation: "Excel spreadsheets are the most common data sources for Mail Merge."
  },
  {
    id: "e10",
    subject: Subject.Excel,
    topic: "Formatting",
    difficulty: Difficulty.Medium,
    type: QuestionType.Scenario,
    question: "You want a cell's background to turn red automatically if the value is less than 35. What tool do you use?",
    options: ["AutoFormat", "Conditional Formatting", "Data Validation", "Cell Styles"],
    correctAnswer: "Conditional Formatting",
    explanation: "Conditional formatting changes a cell's appearance based on its content or specific rules."
  },
  {
    id: "i7",
    subject: Subject.Internet,
    topic: "Web",
    difficulty: Difficulty.Easy,
    type: QuestionType.MCQ,
    question: "Which protocol is used to access the World Wide Web?",
    options: ["FTP", "SMTP", "HTTP", "POP3"],
    correctAnswer: "HTTP",
    explanation: "HTTP (HyperText Transfer Protocol) is the foundation of data communication for the web."
  },
  {
    id: "b8",
    subject: Subject.Basics,
    topic: "Storage",
    difficulty: Difficulty.Medium,
    type: QuestionType.MCQ,
    question: "Which storage device uses no moving parts and is faster than a standard HDD?",
    options: ["CD-ROM", "Floppy Disk", "SSD", "Tape Drive"],
    correctAnswer: "SSD",
    explanation: "Solid State Drives (SSD) use flash memory, making them faster and more durable than spinning Hard Disk Drives (HDD)."
  }
];
